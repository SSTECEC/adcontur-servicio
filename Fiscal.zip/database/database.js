var configDB = {
	host: '107.180.41.251',
	port: '3306',
	user: 'root_sstec',
	password: '12345',
	database: 'adcontur_web_site',
	connectionLimit: 10,
	connectTimeout: 10000,
	acquireTimeout: 10000,
	waitForConnections: true,
	queueLimit: 0
}

module.exports = configDB;